using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CadidateManageWebsite.Pages
{
    public class NotPermissionModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
